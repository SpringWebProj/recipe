package com.linkface.mapper;

import java.util.List;

import com.linkface.entity.FoodItem;

public interface FoodItemsMapper {
	public List<FoodItem> getFooditem();
}

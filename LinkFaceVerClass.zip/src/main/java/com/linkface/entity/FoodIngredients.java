package com.linkface.entity;

import lombok.Data;

@Data
public class FoodIngredients {
	

	private int RECIPEID;

	private String IRDNTNM;
	private String IRDNTCPCTY;
	private int IRDNTTYCODE;
	private String IRDNTTYNM;
}

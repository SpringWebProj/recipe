package com.linkface.entity;

import lombok.Data;

@Data
public class FoodOrder {
	private int RECIPEID;
	private int COOKINGNO;
	private String COOKINGDC;
	private String STRESTEPIMAGEURL;
	private String STEPTIP;
}

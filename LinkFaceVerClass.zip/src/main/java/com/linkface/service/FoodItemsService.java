package com.linkface.service;

import java.util.List;

import com.linkface.entity.FoodItem;

public interface FoodItemsService {
	public List<FoodItem> getFoodItems();
}

package com.linkface.service;

import com.linkface.entity.RecipeGrade;

public interface RecipeGradeService {

	String recipeGradeCUD(RecipeGrade recipeGrade);
	
}

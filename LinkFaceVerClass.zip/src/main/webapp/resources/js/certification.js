$(document).ready(function(){
		
	let messege = `<c:out value="${message}"/>`;
		
	alert(messege);
	window.location.href = "/main";
})